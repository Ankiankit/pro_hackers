# HQ-BOT-
A bot for helping you solve questions for the popular game HQ Trivia. Scrapes HQ Trivia questions by connecting to the websocket and answers them. 
